<?php require("header.php") ?>

<body>

    <div id="wrapper">

<?php require("menu.php") ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Messages</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div id="time_box" style="background-color:black;color:yellow" class="col-xs-2 col-md-4 center">
                    <div style="display:float;font-size:32pt">
                        9
                    </div>
                    <div style="display:float;font-size:12pt">
                        NOV 2017
                    </div>
                </div>
                
                <div id="message_box" style="display:float;font-size:10pt" class="col-xs-10 col-md-8">
                    <p>LIOIOSD OIEW JOIS JOE JOS JOWE OS JO aodfi woi fo ado faofi afiadfa uaodf aos ie wois aosi aueo woasoiuf aogueo aougaoie sjosie reuo woau dfoauf adiouewo feouas</p>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <script src="../data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
