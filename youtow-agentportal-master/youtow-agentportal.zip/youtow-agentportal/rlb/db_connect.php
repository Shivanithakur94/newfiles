<?php
 
$con = mysqli_connect("edrivenapps.com","levar","lb0315lb","vue_library");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
 

?>